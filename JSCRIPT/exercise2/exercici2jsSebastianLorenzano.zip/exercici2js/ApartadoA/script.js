let name = "Sebastian"
let age = 21
let grade = 9.9
const PI = 3.14159
    document.write("Me llamo <b>" + name + "</b>, tengo <b>" + age + "</b> años y me conformo con un <b>" + grade + "</b> en JavaScript <br>")
    document.write("El número PI es igual a <u>" + PI + "</u>")
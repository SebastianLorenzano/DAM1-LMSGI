let num1 = 14
let num2 = 4
let sum = num1 + num2
let res = num1 - num2;
let product = num1 * num2;
document.write('Primer número: <u>' + num1 + '</u><br>Segundo número: <u>' + num2 + '</u><br><br>Suma de ambos: <u>' + sum + '</u><br>Resta de ambos: <u>' + res + '</u><br>Producto de ambos: <u>' + product + '</u><br><br>Incrementamos el primer número. Ahora vale: <u>' + ++num1 + '</u><br>Decremenetamos el segundo número. Ahora vale: <u>' + --num2 + '</u>');
let division = num1 / num2;
document.write('<br><br>Division de ambos: <u>' + division + '</u>');
document.write("Mi primera página con <b>JavaScript</b>. Qué emoción...")
alert("¡ERROR! Eres demasiado sexy para ver esta pagina")
console.log("Es broma. No eres tan sexy")
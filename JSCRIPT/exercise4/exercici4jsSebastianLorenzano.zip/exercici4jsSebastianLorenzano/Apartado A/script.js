document.write("Bucle hecho con <b>WHILE</b><br>")
let i = 0
while (i < 10) {
    document.write("Que llegue ya <u>Semana Santa,</u> ¡por favor!<br>");
    i++;
}
document.write("¿Ha quedado claro?<br><br>")
document.write("Bucle hecho con <b>FOR</b><br>")
for (let i = 0; i < 10; i++) {
    document.write("Que llegue ya <u>Semana Santa,</u> ¡por favor!<br>")
}
document.write("¿Ha quedado claro?")


let year = prompt("¿En qué año naciste?") 
let age = 2024 - year
let ageNextYear = age + 1

    document.write("Naciste en el año " + year + ". <br>")
    document.write("Por lo tanto, tienes " + age + " años. <br>")
    document.write("El año que viene tendras " + ageNextYear + ".")